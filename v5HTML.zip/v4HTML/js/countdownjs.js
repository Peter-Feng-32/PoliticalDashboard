$(function () {

    /* =========================================
        COUNTDOWN 2
     ========================================= */
    $('#clock-a').countdown('2020/09/29').on('update.countdown', function(event) {
      var $this = $(this).html(event.strftime(''
        + '<span class="h1 font-weight-bold">%w</span> week%!w'
        + '<span class="h1 font-weight-bold">%D</span> Days'));
    });

    $('#clock-a2').countdown('2020/10/07').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime(''
          + '<span class="h1 font-weight-bold">%w</span> week%!w'
          + '<span class="h1 font-weight-bold">%D</span> Days'));
      });

      $('#clock-a3').countdown('2020/10/15').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime(''
          + '<span class="h1 font-weight-bold">%w</span> week%!w'
          + '<span class="h1 font-weight-bold">%D</span> Days'));
      });

      $('#clock-a4').countdown('2020/10/22').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime(''
          + '<span class="h1 font-weight-bold">%w</span> week%!w'
          + '<span class="h1 font-weight-bold">%D</span> Days'));
      });

      $('#clock-a5').countdown('2020/11/03').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime(''
          + '<span class="h1 font-weight-bold">%w</span> week%!w'
          + '<span class="h1 font-weight-bold">%D</span> Days'));
      });

      $('#clock-a6').countdown('2020/11/04').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime(''
          + '<span class="h1 font-weight-bold">%w</span> week%!w'
          + '<span class="h1 font-weight-bold">%D</span> Days'));
      });

});